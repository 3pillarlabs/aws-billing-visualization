'use strict';
var elasticsearch=require("elasticsearch");
var elasticClient = new elasticsearch.Client({
	host: process.env.host
});

exports.handler = (event, context, callback) => {
	var res=elasticClient.indices.stats({
	    index: "_all",
	    level: "indices"
  	});
	res.then(data=>{
		callback(null, data); 
	},error=>{
		callback(error, null); 
	});    
};