'use strict';
var elasticsearch = require("elasticsearch");
var elasticClient = new elasticsearch.Client({
    host: process.env.host
});
var agglimit = 10; //Default limit set for aggregation
exports.handler = (event, context, callback) => {
    var indexName = event.company; //Index value
    var startdate = event.strdate + ' 00:00:00';
    var enddate = event.enddate + ' 23:59:59';
    var from = 0;
    var size = 10;
    var sort = {};
    var sorting_order = "asc";
    var sorting_field = "ProductName";
    var filter = {};
    var regionfilter = {};
    var tablefilter = {};
    var aggs = {
        "total_cost": {
            "sum": {
                "field": "BlendedCost"
            }
        },
        "total_quantity": {
            "sum": {
                "field": "UsageQuantity"
            }
        }
    };

    /* Condition for aggregation start here */
    if (event.product === "" && event.region === "" && event.detailreport === "") {
        aggs = {
            "AvailabilityRegion": {
                "terms": {
                    "field": "__AvailabilityRegion",
                    "order": { "TotalBlendedCost": "desc" },
                    "size": agglimit
                },
                "aggs": {
                    "TotalBlendedCost": {
                        "sum": {
                            "field": "BlendedCost"
                        }
                    }
                }
            },
            "product_name": {
                "terms": {
                    "field": "ProductName",
                    "order": { "TotalBlendedCost": "desc" },
                    "size": agglimit
                },
                "aggs": {
                    "TotalBlendedCost": {
                        "sum": {
                            "field": "BlendedCost"
                        }
                    }
                }
            },
            "total_cost": {
                "sum": {
                    "field": "BlendedCost"
                }
            },
            "total_quantity": {
                "sum": {
                    "field": "UsageQuantity"
                }
            }
        };
    } else if (event.product !== "" && event.region === "" && event.detailreport === "") {
        aggs = {
            "AvailabilityRegion": {
                "terms": {
                    "field": "__AvailabilityRegion",
                    "order": { "TotalBlendedCost": "desc" },
                    "size": agglimit
                },
                "aggs": {
                    "TotalBlendedCost": {
                        "sum": {
                            "field": "BlendedCost"
                        }
                    }
                }
            },
            "total_cost": {
                "sum": {
                    "field": "BlendedCost"
                }
            },
            "total_quantity": {
                "sum": {
                    "field": "UsageQuantity"
                }
            }
        };
    }

    if (event.product !== '') {
        filter = { "match": { "ProductName": event.product } };
    }

    if (event.region !== '') {
        regionfilter = { "match": { "__AvailabilityRegion": event.region } };
    }

    sort[sorting_field] = { "order": sorting_order };
    var query = {
        "from": from,
        "size": size,
        "sort": [sort],
        "query": {
            "bool": {
                "must": [
                    {
                        "range": {
                            "UsageStartDate": {
                                "gte": startdate,
                                "format": "yyyy-MM-dd HH:mm:ss"
                            }
                        }
                    },
                    {
                        "range": {
                            "UsageEndDate": {
                                "lte": enddate,
                                "format": "yyyy-MM-dd HH:mm:ss"
                            }
                        }
                    },
                    filter,
                    regionfilter
                ]

            }
        },
        "aggs": aggs,
        "_source": [
            "ProductName",
            "UsageType",
            "__AvailabilityRegion",
            "ItemDescription",
            "UsageStartDate",
            "UsageEndDate",
            "UsageQuantity",
            "BlendedRate",
            "BlendedCost",
            "Operation",
            "aws:*",
            "user:*",
            "ResourceId"
        ]
    };
    var res= elasticClient.search({
        index: indexName,
        body: query
    });

    res.then(data=>{
		callback(null, data); 
	},error=>{
		callback(error, null); 
	});    
};