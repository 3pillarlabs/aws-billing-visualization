'use strict';
var elasticsearch = require("elasticsearch");
var elasticClient = new elasticsearch.Client({
    host: process.env.host
});
var agglimit = 10; //Default limit set for aggregation
exports.handler = (event, context, callback) => {
    var indexName = event.company;
    var startdate = event.strdate + ' 00:00:00';
    var enddate = event.enddate + ' 23:59:59';
    var from = 0;
    var size = 10;
    var filter = {};
    var regionfilter = {};
    var productfilter = {};
    var sorting_order = event.shortingorder;
    var sorting_field = event.sortingfield;

    if (event.size) {
        size = event.size;
    }

    if (event.currentpage) {
        from = ((event.currentpage - 1) * size);
    }

    if (event.filter !== "") {
        filter = {
            "multi_match": {
                "query": event.filter,
                "fields": ["ResourceId", "aws:*", "user:*"],
                "type": "phrase_prefix"
            }
        };
    }

    if (event.region !== "") {
        regionfilter = { "match": { "__AvailabilityRegion": event.region } };
    }

    if (event.product !== "") {
        productfilter = { "match": { "ProductName": event.product } };
    }
    var sort = {};
    sort[sorting_field] = { "order": sorting_order };

    var query = {
        "from": from,
        "size": size,
        "sort": [sort],
        "query": {
            "bool": {
                "must": [
                    {
                        "range": {
                            "UsageStartDate": {
                                "gte": startdate,
                                "format": "yyyy-MM-dd HH:mm:ss"
                            }
                        }
                    },
                    {
                        "range": {
                            "UsageEndDate": {
                                "lte": enddate,
                                "format": "yyyy-MM-dd HH:mm:ss"
                            }
                        }
                    },
                    filter,
                    productfilter,
                    regionfilter

                ]

            }

        },
        "aggs": {
            "total_cost": {
                "sum": {
                    "field": "BlendedCost"
                }
            },
            "total_quantity": {
                "sum": {
                    "field": "UsageQuantity"
                }
            }
        },
        "_source": [
            "ProductName",
            "UsageType",
            "__AvailabilityRegion",
            "ItemDescription",
            "UsageStartDate",
            "UsageEndDate",
            "UsageQuantity",
            "BlendedRate",
            "BlendedCost",
            "Operation",
            "aws:*",
            "user:*",
            "ResourceId"
        ]
    };

	var res= elasticClient.search({
        index: indexName,
        body: query
    })

    res.then(data => {
        callback(null, data);
    }, error => {
        callback(error, null);
    });
};