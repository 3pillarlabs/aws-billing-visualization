'use strict';
var elasticsearch=require("elasticsearch");
var elasticClient = new elasticsearch.Client({
	host: process.env.host
});
var agglimit = 10; //Default limit set for aggregation
exports.handler = (event, context, callback) => {
	var esIndex=event.index
	var res=elasticClient.search({
    index: esIndex,
    size: 0,
    body: {
	      "aggs": {
	        "max_date": { "max": { "field": "UsageEndDate", "format": "YYYY-MM-dd" } },
	        "min_date": { "min": { "field": "UsageStartDate", "format": "YYYY-MM-dd" } },
	        "last_created": { "max": { "field": "__CreatedDate" } },
	        "availability_regions": {
	          "terms": {
	            "field": "__AvailabilityRegion",
	            "order": {
	              "TotalBlendedCost": "desc"
	            },
	            "size": agglimit
	          },
	          "aggs": {
	            "TotalBlendedCost": {
	              "sum": {
	                "field": "BlendedCost"
	              }
	            }
	          }
	        },
	        "product_names": {
	          "terms": {
	            "field": "ProductName",
	            "order": {
	              "TotalBlendedCost": "desc"
	            },
	            "size": agglimit
	          },
	          "aggs": {
	            "TotalBlendedCost": {
	              "sum": {
	                "field": "BlendedCost"
	              }
	            }
	          }
	        }

	      }

	    }
	  });
	res.then(data=>{
		callback(null, data); 
	},error=>{
		callback(error, null); 
	});    
};